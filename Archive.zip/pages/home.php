
    <div class="dfdfbgfnfg">
        <div class="jshdkfgs">Au programme</div>
        <?php  include('../components/programmes.php'); ?>
    </div>
    <div class="dfdfbgfnfg">
        <div class="jshdkfgs">Commin soon</div>
        <?php  include('../components/comming_soon.php'); ?>
    </div>
    <div class="dfdfbgfnfg">
        <div class="jshdkfgs">Promotions</div>
        <div class="home_data">
            <div class="card promo_card" style="background-image: url(https://2.bp.blogspot.com/-eE3UIcamR5I/WgQazCvrHUI/AAAAAAAANB4/8ZexUWQD5n06ciqYwIhjGwzynlT51Q7TgCLcBGAs/s1600/Thor_Ragnarok_Promo_Banner.jpg);">
                
            </div>
            <div class="card promo_card" style="background-image: url(https://www.moviepostershop.com/images/slideshow/new-releases.jpg);">

            </div>
            <div class="card promo_card" style="background-image: url(https://www.ktc.co.th/pub/media/Promotion/Book/visaxmajor-hobbies-cinema-major_promo-m-en.jpg);">
                
            </div>
        </div>   
    </div>
