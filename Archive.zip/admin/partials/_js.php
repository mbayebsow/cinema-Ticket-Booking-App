    <script src="./assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="./assets/vendors/select2/select2.min.js"></script>
    <script src="./assets/vendors/typeahead.js/typeahead.bundle.min.js"></script>
    <script src="./assets/js/off-canvas.js"></script>
    <script src="./assets/js/hoverable-collapse.js"></script>
    <script src="./assets/js/misc.js"></script>
    <script src="./assets/js/file-upload.js"></script>
    <script src="./assets/js/typeahead.js"></script>
    <script src="./assets/js/select2.js"></script>

    <script src="./assets/vendors/chart.js/Chart.min.js"></script>
    <script src="./assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="./assets/vendors/flot/jquery.flot.js"></script>
    <script src="./assets/vendors/flot/jquery.flot.resize.js"></script>
    <script src="./assets/vendors/flot/jquery.flot.categories.js"></script>
    <script src="./assets/vendors/flot/jquery.flot.fillbetween.js"></script>
    <script src="./assets/vendors/flot/jquery.flot.stack.js"></script>
    <script src="./assets/vendors/flot/jquery.flot.pie.js"></script>

    <script src="./assets/js/dashboard.js"></script>
    <script src="./assets/js/ProgPostGet.js"></script>