<?php
    $conn = mysqli_connect("localhost","ccos_user","ccos_password","ccos" ) or die ("error" . mysqli_error($conn));
?>
