<?php
setlocale(LC_TIME, "fr_FR");
    $conn = mysqli_connect("localhost","ccos_user","ccos_password","ccos" ) or die ("error" . mysqli_error($conn));
?>
