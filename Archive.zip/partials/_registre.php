<form id="register-form"  class="form-container">
  <h1>Inscription</h1>
  <div class="form-group">
    <input id="user_name" type="text" class="form-control" placeholder="Username" name="user_name"/>
  </div>
  <div class="form-group">
    <input id="user_email" type="email" class="form-control" placeholder="Email address" name="user_email"/>
  </div>
  <div class="form-group">
    <input id="rpassword" type="password" class="form-control" placeholder="Password" name="rpassword"/>
  </div>
  <div class="form-group">
    <input id="cpassword" type="password" class="form-control" placeholder="Retype Password" name="cpassword"/>
  </div>
  <div class="form-group">
    <button type="submit" class="btn btn-default" name="register_button" id="btn-submit">Create Account</button> 
  </div> 
  <div id="connexion" onclick="connexion()"  class="cmt">Vous avez deja un compte? Se Connectez ici!</div>
</form>

<script>
  $('document').ready(function() {   
    $("#register-form").validate({
      rules:{
        user_name: {
          required: true,
          minlength: 3
        },
        rpassword: {
          required: true,
          minlength: 8,
          maxlength: 15
        },
        cpassword: {
          required: true,
          equalTo: '#rpassword'
        },
        user_email: {
          required: true,
          email: true
        },
      },
      messages: {
        user_name: "veuillez entrer le nom d'utilisateur",
        rpassword:{
          required: "veuillez fournir un mot de passe",
          minlength: "le mot de passe comporte au moins 8 caractères"
        },
        user_email: "S'il vous plaît, mettez une adresse email valide",
        cpassword:{
          required: "merci de retaper votre mot de passe",
          equalTo: "le mot de passe ne correspond pas !"
        }
      },
      submitHandler: submitForm 
    });  
      /* handle form submit */
    function submitForm() {  
      var data = $("#register-form").serialize();    
      $.ajax({    
        type : 'POST',
        url  : 'partials/login_registre_api.php',
        data : data,
        beforeSend: function() { 
          $("#btn-submit").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; sending ...');
        },
        success : function(dataresponse){
          var result = jQuery.parseJSON(dataresponse);

          if (result.code == 200){
            $.dialog({
              title: result.message,
              content: 'Salut '+result.prenom+' '+result.nom+' bienvenue parmis nous.',
            });
            //setCookie("session_id",result.id,30);
            //closeForm();
            //function timedRefresh(timeoutPeriod) {
            //  setTimeout("location.reload(true);",timeoutPeriod);
            //}
            //window.onload = timedRefresh(1500);
          }
          else if (result.code == 201){
            $.dialog({
              title: result.message,
              content: 'L\'adresse email que vous avez saisie existe déjà.',
            });
          }
          else if (result.code == 202){
            $.dialog({
              title: result.message,
              content: 'Vérifiez que vous avez saisie les bonne caractere.',
            });
          }
        }
      });
      return false;
    }
  });
</script>