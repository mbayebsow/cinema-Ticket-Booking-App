        <?php include('includes/header.php'); ?>

        <div id="page-wrapper"></div>

        <div class="nav-bottom">
            <div id="menuactive"></div>
            <button class="tablink" id="Home" onclick="Home()"><i class="fas fa-th-large"></i><span>Home</span></button>
            <button class="tablink" id="Ticket" onclick="Ticket()"><i class="fas fa-receipt"></i><span>Tickets</span></button>
            <button class="tablink" id="User" onclick="User()"><i class="fas fa-user"></i><span>Compte</span></button>
        </div>
        <script>
            HomePage();
            function Home() {
                HomePage();
            }
            function Ticket() {
                TicketPage()
            }
            function User() {
                UserPage();

            }
        </script>
    </body>
</html>
