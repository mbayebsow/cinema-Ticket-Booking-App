<div id="header-wrapper">
    <div class="top-nav">
        <a href="#" class="navbar-brand" data-bjax="">
            <img class="logo_img" src ="/src/img/CCOS.png"/>
        </a>
        <div class="float_right">
            <i class="fas fa-bell home-icon"></i>
            <i class="fas fa-search home-icon"></i>
        </div>  
    </div>
</div>