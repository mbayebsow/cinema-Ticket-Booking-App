<div id="header-wrapper">
    <div class="top-nav">
        <a href="<?php echo $previous ?>" class="navbar-brand" data-bjax="">
            <i class="fas fa-arrow-left" style="background: #d0d0d061;"></i>
        </a>
        <div class="float_right">
        <i class="far fa-bookmark" style="background: #d0d0d061;"></i><i class="fas fa-share" style="background: #d0d0d061;"></i>
        </div>
    </div>
</div>
<style>
#header-wrapper {
    background: transparent !important;
}
</style>