<button class="btn open-button" id="btnconnect" onclick="openForm()">Connexion / S'inscrire</button>
<script>
  function openForm() {
    modale()
    inscription();
    return;
  }
</script>